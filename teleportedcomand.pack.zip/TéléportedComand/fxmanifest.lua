fx_version 'bodacious'
game 'gta5'
lua54 'yes'
shared_script 'config.lua'
shared_script 'locales.lua'
client_script 'client.lua'
server_script 'server.lua'

dependency '/assetpacks'