Config = {}

-- Définition des destinations avec leurs coordonnées de téléportation
Config.Destinations = {
    vespucci = { x = -1117.1141357422, y = -855.177734375, z = 19.692981719971, heading = 310.31683349609 },
    mr = { x =440.20303344727, y =-982.97528076172, z =30.689601898193, heading = 90.0 },
    sandyshores = { x = 1693.7221679688, y = 3794.0786132813, z = 34.70512008667, heading = 90.0 }
}

-- Langue par défaut
Config.Locale = 'en'
